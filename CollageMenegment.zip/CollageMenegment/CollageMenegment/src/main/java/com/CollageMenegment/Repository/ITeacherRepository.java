package com.CollageMenegment.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CollageMenegment.model.Teacher;

public interface ITeacherRepository extends JpaRepository<Teacher, Long>{

}
