package com.CollageMenegment.Service;

import java.util.List;
import java.util.Optional;

import com.CollageMenegment.model.Department;

public interface IDepartmentService {

	Department create(Department dept);

	List<Department> getAllDepartment();

	void deleteDepartment(Long deptId);

	Optional<Department> getById(Long deptId);

	Department updateById(Long deptId);

	Department updateDepartment(Department d);

}
