package com.CollageMenegment.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CollageMenegment.Repository.IDepartmentRepository;
import com.CollageMenegment.Service.IDepartmentService;
import com.CollageMenegment.model.Department;

@Service
public class DepartmentServiceImpl implements IDepartmentService{
	
	@Autowired
	 private IDepartmentService service;
	
	@Autowired
	private IDepartmentRepository  reo;
	private static Logger logger = LogManager.getLogger(DepartmentServiceImpl.class);

	@Override
	public Department create(Department dept) {
		logger.info(" DepartmentServiceImpl create()", dept);
		
		return reo.save(dept);
	}

	@Override
	public List<Department> getAllDepartment() {
		logger.info(" DepartmentServiceImpl getAllDepartment()");
	
		return reo.findAll();
	}
	
	@Override
	public Optional<Department> getById(Long departmentId) {
		logger.info(" DepartmentServiceImpl getById()", departmentId);
		return reo.findById(departmentId);
	}

	@Override
	public void deleteDepartment(Long deptId) {
		logger.info(" DepartmentServiceImpl getById()", deptId);
			reo.deleteById(deptId);
	}

	@Override
	public Department updateById(Long deptId) {
		logger.info(" DepartmentServiceImpl updateById()", deptId);
		return reo.getById(deptId);
	}

	@Override
	public Department updateDepartment(Department d) {
		logger.info(" DepartmentServiceImpl updateDepartment()", d);
		return reo.save(d);
	}

	

}
