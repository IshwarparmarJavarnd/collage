package com.CollageMenegment.controller;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CollageMenegment.Service.IDepartmentService;
import com.CollageMenegment.Service.Impl.DepartmentServiceImpl;
import com.CollageMenegment.Service.Impl.StudentServiceImpl;
import com.CollageMenegment.model.Department;

@RestController
@RequestMapping
@CrossOrigin(origins = "*")
public class DepartmentController {
	

	@Autowired 
	private IDepartmentService services;
	
	private static Logger logger = LogManager.getLogger(DepartmentServiceImpl.class);
	
	@PostMapping("/department")
	public Department create(@RequestBody Department dept)
	{
		logger.info(" DepartmentServiceImpl create()", dept);
		return services.create(dept);
	}	
	@GetMapping("/Alldepartment")
	public List<Department> getAllDepartment(){
		logger.info(" DepartmentServiceImpl getAllDepartment()");
		return services.getAllDepartment();
		
	}
	@GetMapping("/department/{deptId}")
	public Optional<Department> getById(@PathVariable("deptId") Long deptId){
		logger.info(" DepartmentServiceImpl getById()", deptId);
		return services.getById(deptId);
	}
	@DeleteMapping("/deletedepartment/{deptId}")
	public void deleteDepartment(@PathVariable("deptId") Long deptId) {
		logger.info(" DepartmentServiceImpl deleteDepartment()", deptId);
		services.deleteDepartment(deptId);
	
	}
	
	@PutMapping("/updateDepartment/{deptId}")
	public Department updateDepartment(@PathVariable("deptId") Long deptId,@RequestBody Department dept) {
		logger.info(" DepartmentServiceImpl updateDepartment()", deptId);
		Department d=services.updateById(deptId);
		d.setDeptHod(dept.getDeptHod());
		d.setDeptLocation(dept.getDeptLocation());
		d.setDeptName(dept.getDeptName());
		
		return services.updateDepartment(d);
		
	}

}
