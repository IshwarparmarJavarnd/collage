package com.CollageMenegment.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;



@Entity
public class StudentClass {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long classId;
	
	private String className;
	
	@OneToMany
	private List<Teacher> teacher = new ArrayList<>();
	
	@OneToMany
	private List<Student> student = new ArrayList<>();
	  
	public StudentClass(Long classId, String className, List<Teacher> teacher, List<Student> student) {
		super();
		this.classId = classId;
		this.className = className;
		this.teacher = teacher;
		this.student = student;
	}
	public Long getClassId() {
		return classId;
	}
	public void setClassId(Long classId) {
		this.classId = classId;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	

	 public StudentClass() {
		// TODO Auto-generated constructor stub
	}
		
}
